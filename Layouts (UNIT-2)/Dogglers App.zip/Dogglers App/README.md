Dogglers App

This is an app that shows gallery of selected dogs with their characteristics.
It can be modified to show your own collection of animals, jewelery and etc.

This app was built using Scrollable Lists in Training for Android Basics in Kotlin:
https://developer.android.com/courses/pathways/android-basics-kotlin-unit-2-pathway-3

